def parsear_factura(file_stream):
    """
    Extrae los datos básicos de la factura PDF y devuelve un dict.
    """
    # TODO: usar pdfplumber o pdfminer o PyMuPDF
    return {}
