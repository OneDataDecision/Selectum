import os
from flask import Flask
from dotenv import load_dotenv

def create_app():
    # Carga variables de entorno
    load_dotenv()

    app = Flask(__name__)
    app.config.from_pyfile('config.py')

    # Registrar blueprints
    from routes.facturas import facturas_bp
    from routes.despachos import despachos_bp
    app.register_blueprint(facturas_bp)
    app.register_blueprint(despachos_bp)

    # Registro de cierre de DB al contexto
    from database.db import close_db
    app.teardown_appcontext(close_db)

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, port=int(os.getenv('PORT', 5001)))
