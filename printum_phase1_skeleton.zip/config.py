import os

# Configuración general
SECRET_KEY = os.getenv('SECRET_KEY', 'dev_key')
DB_PATH = os.getenv('DB_PATH', 'selectum.db')
UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', 'static/evidencias')
