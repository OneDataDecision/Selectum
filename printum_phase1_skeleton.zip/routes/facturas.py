from flask import Blueprint, render_template, request

facturas_bp = Blueprint('facturas', __name__, url_prefix='/facturas')

@facturas_bp.route('/cargar', methods=['GET', 'POST'])
def cargar_factura():
    # TODO: implementar lógica de carga
    if request.method == 'POST':
        pass
    return render_template('cargar_factura.html')
