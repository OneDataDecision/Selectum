from flask import Blueprint, render_template

despachos_bp = Blueprint('despachos', __name__, url_prefix='/despachos')

@despachos_bp.route('/', methods=['GET'])
def index():
    return render_template('inicio.html')
